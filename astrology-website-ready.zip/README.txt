Astrology Website Setup

1. Upload all files to GitHub
2. Deploy backend on Render
3. Add your Claude API key in environment variables
4. Use the frontend HTML file for your website

Files included:
- package.json
- .env.example
- README.txt

Frontend HTML and backend JS were created in canvas already.
